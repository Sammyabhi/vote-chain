import Button from '@restart/ui/esm/Button';
import React from 'react';



function Register() {
  return (
    <body className='candetails-body'>
            <div className='candetails-box'>
                <h1 className='candetails-h1'>Register Voters</h1>
            <table class='candetails-table'>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Adhar no</th>
                    <th>Account address</th>
                    <th>Is registered</th>
                    
                </tr>
                <tr>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
               
            </table>
            <div>
              <input className='register-input'></input>
            </div>
            <br></br>
            <button className = 'button1' id = 'button1'>Change Phase</button>
            
            </div>

        </body>
  );
}


export default Register;
