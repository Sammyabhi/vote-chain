import React from 'react';



function Logout() {
  return (
    /*<Link to="../Home"></Link>*/
    <h1></h1>
  );
}


export default Logout;

